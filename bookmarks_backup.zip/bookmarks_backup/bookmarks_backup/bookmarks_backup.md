Use bookmarks_backup.json for bookmark import.
Do not import README.json into Chrome.